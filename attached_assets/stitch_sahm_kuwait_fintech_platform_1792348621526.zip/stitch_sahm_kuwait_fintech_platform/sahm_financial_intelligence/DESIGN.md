---
name: Sahm Financial Intelligence
colors:
  surface: '#fbf9f3'
  surface-dim: '#dcdad4'
  surface-bright: '#fbf9f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ed'
  surface-container: '#f0eee8'
  surface-container-high: '#eae8e2'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c18'
  on-surface-variant: '#404846'
  inverse-surface: '#30312d'
  inverse-on-surface: '#f3f1eb'
  outline: '#717976'
  outline-variant: '#c0c8c5'
  surface-tint: '#3c665d'
  primary: '#002620'
  on-primary: '#ffffff'
  primary-container: '#103d35'
  on-primary-container: '#7ca89d'
  inverse-primary: '#a3d0c4'
  secondary: '#246a55'
  on-secondary: '#ffffff'
  secondary-container: '#abf1d6'
  on-secondary-container: '#2b705b'
  tertiary: '#2d1e00'
  on-tertiary: '#ffffff'
  tertiary-container: '#483200'
  on-tertiary-container: '#be9953'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bfece0'
  primary-fixed-dim: '#a3d0c4'
  on-primary-fixed: '#00201b'
  on-primary-fixed-variant: '#234e45'
  secondary-fixed: '#abf1d6'
  secondary-fixed-dim: '#90d4bb'
  on-secondary-fixed: '#002117'
  on-secondary-fixed-variant: '#00513e'
  tertiary-fixed: '#ffdea5'
  tertiary-fixed-dim: '#e9c176'
  on-tertiary-fixed: '#261900'
  on-tertiary-fixed-variant: '#5d4201'
  background: '#fbf9f3'
  on-background: '#1b1c18'
  surface-variant: '#e4e2dd'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.5rem
    fontWeight: '800'
    lineHeight: '1.15'
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: '1.25'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: '1.35'
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: '0'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.65'
    letterSpacing: '0'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.9375rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.03em
  stat-metric:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-tablet: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

### Brand Personality & Core Mood
The design system embodies Kuwaiti financial refinement, computational trust, and intellectual clarity. Designed to transform complex, intimidating Boursa Kuwait regulatory filings into intuitive, actionable insights for retail and emerging investors, the platform prioritizes transparency, dignity, and calm competence. The visual atmosphere merges institutional private banking stature with modern Arabian digital elegance.

### Design Movement & Aesthetic Expression
The platform adheres to **Warm Institutional FinTech Modernism** with an **RTL-first native architecture**. It eschews sterile neo-banking coldness in favor of heritage-rooted luxury: rich, deep petroleum emerald surfaces, warm architectural ivory canvases, subtle golden micro-accents, crisp hairline separators, and floating multi-layered cards with soft ambient shadows. Visual hierarchy is disciplined, generous with whitespace, and optimized for bilingual numeracy and textual cadence.

## Colors

### Color Philosophy
The color system honors the prestige of regional commerce through deep emerald green as the foundational anchor, representing stability, authority, and prosperity. Muted sage green acts as a transitional bridge for structural surfaces, interactive hover states, and positive performance metrics. Warm ivory replaces clinical stark white to reduce cognitive fatigue during dense financial review. Soft warm gold functions strictly as an editorial accent for verification emblems, premium tiers, and critical KPI highlights.

### Semantic & Palette Mapping
- **Canvas & Primary Surface**: Warm Ivory (`#F4F2EC`) and Pure Card Ivory (`#FFFFFF`).
- **Brand Primary & Deep Container**: Deep Emerald (`#103D35`), with an ink variant (`#0D332C`) for dark-mode sidebars and high-prominence navigation bars.
- **Secondary & Accent**: Muted Sage / Mint (`#458872`) and Light Sage Tint (`#EAF2EE`) for status tags, metric badges, and interactive secondary triggers.
- **Prestige Accent**: Warm Sand Gold (`#C5A059`), deployed sparingly on verified indicators, badges, and focus borders.
- **Functional Border & Divider**: Muted Gray Stone (`#E5E7EB`), offering architectural definition without visual clutter.
- **Text & Reading Hierarchy**: Deep Pine Noir (`#0E2420`) for headline legibility, Muted Charcoal Slate (`#4B5563`) for descriptive context, and Light Subdued Silver (`#9CA3AF`) for captions and metadata.

## Typography

### Bilingual Typographic Strategy
The type system supports seamless dual-script harmony across Arabic and Latin scripts. Arabic type utilizes modern geometric neo-grotesque styling (such as Alexandria or IBM Plex Sans Arabic), which aligns naturally with Plus Jakarta Sans in x-height, stroke density, and terminal sharpness. 

### Alignment & Numeracy Rules
- **RTL Primary**: Content flow begins from right to left with mirrored leading and trailing insets.
- **Financial Numerals**: Western Arabic digits (1, 2, 3) and Eastern Arabic digits (١, ٢, ٣) are rendered with tabular figure alignment (`tnum`) in financial metrics to ensure decimal parity across balance sheet comparisons.
- **Leading & Line Rhythm**: Arabic type requires 10-15% more vertical line space than Latin equivalents to preserve diacritic integrity and prevent character collision.

## Layout & Spacing

### Layout Architecture & Grid Structure
The responsive layout system is structured around an adaptive 12-column grid for desktop views, converting to 8 columns on tablet and 4 columns on mobile viewports. Max viewport content is constrained to `1320px` to maintain optimal scanning width for financial statements and multi-metric dashboards.

- **Desktop (1280px+)**: 12 columns, 24px gutters, 48px outer canvas padding. Sidebar width fixed at 260px for consistent internal tool navigation.
- **Tablet (768px - 1279px)**: 8 columns, 16px gutters, 32px canvas margins. Secondary analytics and side-by-side metric tables stack into vertical sequences.
- **Mobile (< 768px)**: 4 columns, 16px gutters, 20px margins. Persistent bottom navigation bar with a centered floating action trigger (`+` report submission).

### Spacing Principles
Padding follows an 8-point compositional grid. Compact financial data cells leverage `space-xs` and `space-sm` for high-density information retention, while external card shells and layout divisions employ `space-lg` and `space-xl` to reinforce visual calm and editorial pacing.

## Elevation & Depth

### Depth Paradigm & Layering Strategy
Depth is achieved through **Tonal Layering combined with Emerald-Tinted Ambient Shadows**. High-elevation physical drop shadows are rejected in favor of soft, diffused luminous envelopes that give cards an organic, lifted presence.

### Layer Hierarchy
1. **Foundation Level (Canvas)**: Warm Ivory (`#F4F2EC`), pure planar background.
2. **Structural Tier 1 (Cards & Data Surfaces)**: Pure White (`#FFFFFF`) cards outlined with a 1px border of `rgba(16, 61, 53, 0.08)`. Shadow formula: `0 4px 20px -2px rgba(16, 61, 53, 0.05), 0 2px 6px -1px rgba(16, 61, 53, 0.03)`.
3. **Structural Tier 2 (Hover & Active Focus States)**: The card elevates slightly with an increased emerald wash: `0 12px 32px -4px rgba(16, 61, 53, 0.09), 0 4px 12px -2px rgba(16, 61, 53, 0.04)`.
4. **Institutional Command Tier (Sidebar & Header Elements)**: Solid Deep Emerald (`#103D35` / `#0D332C`) surfaces featuring inset lighting (`inset 0 1px 0 rgba(255, 255, 255, 0.08)`) with zero drop shadow to maintain architectural grounding.
5. **Overlays & Modals**: Soft blur (`backdrop-filter: blur(12px)`) using an ivory-tinted barrier (`rgba(244, 242, 236, 0.75)`), drawing focus cleanly toward analytical modals.

## Shapes

### Shape Language & Geometry
The design system pairs clean, institutional authority with friendly consumer accessibility by using a unified `roundedness: 2` (0.5rem / 8px base) system that scales up to generous `1rem` (16px) and `1.25rem` (20px) radiuses on cards, drawers, and metric modules. 

- **Primary Interactive Containers & Large Cards**: Standardized at `rounded-2xl` (16px - 20px) to deliver the signature card aesthetic seen across analytical sheets and company overviews.
- **Buttons, Dropdowns, and Input Fields**: Standardized at `rounded-xl` (12px) for comfortable touch targets and ergonomic balance.
- **Pills, Badges, and Status Metrics**: Full pill curvature (`9999px`) to distinguish categorical indicators from actionable rectangular structural modules.
- **Drop Zones (Upload)**: Dashed border enclosure (`1.5px`) with `rounded-2xl` curvature, communicating safety and intuitive drop functionality.

## Components

### Buttons
- **Primary Action**: Deep emerald solid background (`#103D35`), pure white text, `rounded-xl` (12px) border radius, subtle emerald ambient glow on hover (`0 6px 16px rgba(16, 61, 53, 0.25)`). Integrated leading or trailing iconography for RTL file uploads or downloads.
- **Secondary Action**: Warm ivory/sage tinted container (`#EAF2EE`), sage text (`#103D35`), with zero border.
- **Ghost/Text**: Transparent background, text colored with deep pine, underlines only occurring upon interaction.

### Metric Cards (KPI Displays)
- Crisp white canvas, 1px border (`rgba(16, 61, 53, 0.08)`), `rounded-2xl` (16px) corner radius.
- Includes a distinct metric title (caption-level slate), dynamic large bold numerical figure (`2rem`, bold), and a pill-shaped performance badge pinned to the top corner containing directional indicators (e.g., `+12%` in muted mint container with emerald green typography).

### File Upload Dropzone
- Framed in a double-state responsive box with rounded-2xl geometry.
- Default state: Sand-tinted neutral surface (`rgba(255, 255, 255, 0.7)`), 1.5px dashed border in muted sage (`#75A995`), featuring a centered mint-tinted circular icon container with upward arrow glyph.
- Drag-over state: Transition to emerald-tinted wash with border solidifying in `#103D35`.

### Accordion & Analytical Explainer Blocks
- Structured for beginner clarity. Header row highlights the financial concept (e.g., "صافي الأرباح" / Net Profit) in semi-bold weight accompanied by chevron rotation.
- Expanded container reveals an AI simplification card: plain-language contextual breakdown, linked page citations back to the source financial filing (e.g., "الصفحة ٥ من التقرير"), and a warm gold badge for verified metrics.

### Segmented Controls & Language Switcher
- Pill-shaped enclosure (`rounded-full`) with a muted neutral background (`#E5E7EB`). Active state is represented by an elevated floating capsule (`#103D35` with white text, or pure white with dark emerald text).

### Navigation & Bottom Dock
- **Desktop Sidebar**: Vertical layout in dark emerald (`#103D35`), navigation items styled as soft-edged horizontal tabs with mint-tinted active indicator pills.
- **Mobile Navigation Dock**: Fixed bottom bar with blurred ivory backdrop, 4 primary tab touchpoints, and an elevated deep-emerald circular action button (`48px x 48px`) floating in the center position.